from flask import Flask, render_template, request, redirect, url_for, session
from db import init_db, insert_price, get_prices, get_tracked_games, add_tracked_game
from get_steam_price import get_steam_price
from scheduler import start_scheduler

app = Flask(__name__)
app.secret_key = "your_secret_key"
init_db()
start_scheduler()

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        game = request.form["query"]
        result = get_steam_price(game)
        if result:
            insert_price(result["name"], result["current_price"])
            tracked = session.get("tracked", [])
            if game not in tracked:
                tracked.append(game)
                session["tracked"] = tracked
                add_tracked_game(game)
        return render_template("index.html", result=result, tracked=session.get("tracked", []))
    return render_template("index.html", result=None, tracked=session.get("tracked", []))

@app.route("/history/<game>")
def history(game):
    data = get_prices(game)
    return render_template("history.html", game=game, data=data)

if __name__ == "__main__":
    app.run(debug=True)