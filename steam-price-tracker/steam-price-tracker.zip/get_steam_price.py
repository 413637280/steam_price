import requests
from bs4 import BeautifulSoup

def get_steam_price(game_name):
    url = f"https://store.steampowered.com/search/?term={game_name}"
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.text, "html.parser")
    result = soup.find("div", class_="search_result_row")
    if result:
        title = result.find("span", class_="title").text.strip()
        price = result.find("div", class_="search_price").text.strip()
        return {"name": title, "current_price": price}
    return None