import sqlite3
from datetime import datetime

DB_NAME = "price_data.db"

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS price_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            game_name TEXT,
            price TEXT,
            query_time TEXT
        )
    ''')
    c.execute('''
        CREATE TABLE IF NOT EXISTS tracked_games (
            game_name TEXT PRIMARY KEY
        )
    ''')
    conn.commit()
    conn.close()

def insert_price(game_name, price):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    c.execute('''
        INSERT INTO price_history (game_name, price, query_time)
        VALUES (?, ?, ?)
    ''', (game_name, price, now))
    conn.commit()
    conn.close()

def get_prices(game_name):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''
        SELECT price, query_time FROM price_history
        WHERE game_name = ?
        ORDER BY query_time
    ''', (game_name,))
    rows = c.fetchall()
    conn.close()
    return rows

def add_tracked_game(game_name):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("INSERT OR IGNORE INTO tracked_games (game_name) VALUES (?)", (game_name,))
    conn.commit()
    conn.close()

def get_tracked_games():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT game_name FROM tracked_games")
    games = [row[0] for row in c.fetchall()]
    conn.close()
    return games