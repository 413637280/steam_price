#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Steam Price Tracker - 資料庫管理工具
用於初始化、檢查和維護資料庫
"""

import sqlite3
import os
import sys
from datetime import datetime

def check_database_exists():
    """檢查資料庫檔案是否存在"""
    db_files = ["prices.db", "price_data.db"]
    existing_files = []
    for db_file in db_files:
        if os.path.exists(db_file):
            size = os.path.getsize(db_file)
            existing_files.append(f"{db_file} ({size} bytes)")
    return existing_files

def init_main_database():
    """初始化主要資料庫"""
    print("正在初始化主要資料庫...")
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    
    # 建立價格歷史表
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS price_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_name TEXT NOT NULL,
        price REAL NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)
    
    # 建立追蹤遊戲表
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS tracked_games (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_name TEXT UNIQUE NOT NULL,
        added_date DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)
    
    # 建立索引
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_price_history_game_name 
    ON price_history(game_name)
    """)
    
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_price_history_timestamp 
    ON price_history(timestamp)
    """)
    
    conn.commit()
    conn.close()
    print("主要資料庫初始化完成")

def init_user_database():
    """初始化用戶相關資料庫"""
    print("正在初始化用戶資料庫...")
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    
    # 建立用戶表
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)
    
    # 建立價格提醒表
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS price_alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL,
        game_name TEXT NOT NULL,
        target_price REAL NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        is_active BOOLEAN DEFAULT 1,
        UNIQUE(username, game_name),
        FOREIGN KEY(username) REFERENCES users(username)
    )
    """)
    
    conn.commit()
    conn.close()
    print("用戶資料庫初始化完成")

def check_database_structure():
    """檢查資料庫結構"""
    print("正在檢查資料庫結構...")
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    
    # 獲取所有表格
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [row[0] for row in cursor.fetchall()]
    
    print(f"找到表格: {', '.join(tables)}")
    
    # 檢查每個表格的結構和記錄數量
    for table in tables:
        cursor.execute(f"PRAGMA table_info({table})")
        columns = cursor.fetchall()
        
        cursor.execute(f"SELECT COUNT(*) FROM {table}")
        count = cursor.fetchone()[0]
        
        print(f"\n表格: {table} ({count} 筆記錄)")
        for col in columns:
            print(f"   - {col[1]} ({col[2]})")
    
    conn.close()
    print("\n資料庫結構檢查完成")

def insert_sample_data():
    """插入範例資料"""
    print("正在插入範例資料...")
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    
    try:
        # 插入範例遊戲追蹤
        sample_games = ["Cyberpunk 2077", "The Witcher 3", "Portal 2"]
        for game in sample_games:
            try:
                cursor.execute("INSERT OR IGNORE INTO tracked_games (game_name) VALUES (?)", (game,))
            except:
                pass
        
        # 插入範例價格
        sample_prices = [
            ("Cyberpunk 2077", 1790.0),
            ("The Witcher 3", 569.0),
            ("Portal 2", 268.0)
        ]
        
        for game, price in sample_prices:
            try:
                cursor.execute("INSERT INTO price_history (game_name, price) VALUES (?, ?)", (game, price))
            except:
                pass
        
        conn.commit()
        print("範例資料插入完成")
        
    except Exception as e:
        print(f"插入範例資料失敗: {e}")
    
    finally:
        conn.close()

def backup_database():
    """備份資料庫"""
    if os.path.exists("prices.db"):
        backup_name = f"prices_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
        import shutil
        shutil.copy2("prices.db", backup_name)
        print(f"資料庫已備份至: {backup_name}")
        return backup_name
    else:
        print("找不到資料庫檔案")
        return None

def main():
    """主要執行函數"""
    print("=" * 50)
    print("    Steam Price Tracker - 資料庫管理工具")
    print("=" * 50)
    print()
    
    # 檢查現有資料庫檔案
    existing_files = check_database_exists()
    if existing_files:
        print("找到現有資料庫檔案:")
        for file in existing_files:
            print(f"   - {file}")
        print()
    else:
        print("未找到現有資料庫檔案，將建立新的資料庫")
        print()
    
    # 初始化資料庫
    init_main_database()
    init_user_database()
    
    # 檢查結構
    check_database_structure()
    
    # 詢問是否插入範例資料
    if not existing_files:
        choice = input("\n是否插入範例資料？(y/n): ").lower().strip()
        if choice == 'y':
            insert_sample_data()
    
    print("\n資料庫管理完成！")
    print("\n下一步:")
    print("   1. 執行 start.bat 啟動應用程式")
    print("   2. 訪問 http://127.0.0.1:5000/debug 查看系統狀態")
    print("   3. 訪問 http://127.0.0.1:5000 開始使用")

if __name__ == "__main__":
    main()
