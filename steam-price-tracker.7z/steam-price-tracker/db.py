import sqlite3
import os
from datetime import datetime

def init_db():
    """初始化主要資料庫表格"""
    print("正在初始化主資料庫...")
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    
    # 建立價格歷史表
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS price_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_name TEXT,
        price REAL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)
    
    # 建立追蹤遊戲表
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS tracked_games (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        game_name TEXT UNIQUE,
        added_date DATETIME DEFAULT CURRENT_TIMESTAMP
    )
    """)
    
    # 建立索引以提升查詢效能
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_price_history_game_name 
    ON price_history(game_name)
    """)
    
    cursor.execute("""
    CREATE INDEX IF NOT EXISTS idx_price_history_timestamp 
    ON price_history(timestamp)
    """)
    
    conn.commit()
    conn.close()
    print("主資料庫表格建立完成")

def check_db_status():
    """檢查資料庫狀態"""
    try:
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        
        # 檢查表格
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        
        # 檢查各表格的記錄數量
        stats = {}
        for table in tables:
            cursor.execute(f"SELECT COUNT(*) FROM {table}")
            count = cursor.fetchone()[0]
            stats[table] = count
        
        conn.close()
        return {"status": "success", "tables": tables, "stats": stats}
    
    except Exception as e:
        return {"status": "error", "message": str(e)}

def insert_price(game_name, price):
    """插入價格記錄"""
    try:
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO price_history (game_name, price) VALUES (?, ?)",
            (game_name, float(price))
        )
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"插入價格失敗: {e}")
        return False

def get_prices(game_name):
    """獲取遊戲價格歷史"""
    conn = sqlite3.connect("prices.db")
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute(
        "SELECT price, timestamp FROM price_history WHERE game_name = ? ORDER BY timestamp",
        (game_name,)
    )
    rows = cursor.fetchall()
    conn.close()
    data = []
    for row in rows:
        data.append({
            "price": row["price"],
            "timestamp": row["timestamp"]
        })
    return data

def get_latest_price(game_name):
    """獲取遊戲最新價格"""
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    cursor.execute(
        "SELECT price, timestamp FROM price_history WHERE game_name = ? ORDER BY timestamp DESC LIMIT 1",
        (game_name,)
    )
    result = cursor.fetchone()
    conn.close()
    return result

def cleanup_old_records(days=30):
    """清理舊記錄"""
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    cursor.execute(
        "DELETE FROM price_history WHERE timestamp < datetime('now', '-{} days')".format(days)
    )
    deleted = cursor.rowcount
    conn.commit()
    conn.close()
    return deleted

def add_tracked_game(game_name):
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    try:
        cursor.execute(
            "INSERT OR IGNORE INTO tracked_games (game_name) VALUES (?)",
            (game_name,)
        )
        conn.commit()
    except Exception as e:
        print(f"Add tracked game error: {e}")
    finally:
        conn.close()
