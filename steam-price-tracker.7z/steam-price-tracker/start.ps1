Set-Location "c:\Users\AA\Downloads\steam-price-tracker\steam-price-tracker"
$env:FLASK_APP = "app.py"
Write-Host "正在啟動 Steam 價格追蹤器..." -ForegroundColor Green
Write-Host "網址將會是: http://127.0.0.1:5000" -ForegroundColor Yellow
python app.py
