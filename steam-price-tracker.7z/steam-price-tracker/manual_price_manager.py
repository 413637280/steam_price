#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Steam Price Tracker - 手動資料管理工具
用於手動插入、編輯和管理遊戲價格資料
"""

import sqlite3
import sys
from datetime import datetime

def show_menu():
    """顯示主選單"""
    print("\n" + "="*60)
    print("    Steam Price Tracker - 手動資料管理工具")
    print("="*60)
    print()
    print("1. 手動插入遊戲價格")
    print("2. 查看現有價格記錄")
    print("3. 管理收藏遊戲")
    print("4. 刪除價格記錄")
    print("5. 查看遊戲價格歷史")
    print("6. 批量導入價格資料")
    print("7. 匯出價格資料")
    print("8. 退出")
    print()

def insert_manual_price():
    """手動插入遊戲價格"""
    print("\n手動插入遊戲價格")
    print("-" * 30)
    
    game_name = input("請輸入遊戲名稱: ").strip()
    if not game_name:
        print("遊戲名稱不能為空")
        return
    
    try:
        price_str = input("請輸入價格 (例: 1790 或 1790.50): ").strip()
        price = float(price_str)
        if price < 0:
            print("價格不能為負數")
            return
    except ValueError:
        print("價格格式錯誤，請輸入數字")
        return
    
    # 詢問是否要自訂時間
    use_custom_time = input("是否使用自訂時間？(y/n, 預設為當前時間): ").lower().strip()
    timestamp = None
    
    if use_custom_time == 'y':
        try:
            time_str = input("請輸入時間 (格式: YYYY-MM-DD HH:MM, 例: 2024-01-15 14:30): ").strip()
            timestamp = datetime.strptime(time_str, "%Y-%m-%d %H:%M").strftime("%Y-%m-%d %H:%M:%S")
        except ValueError:
            print("時間格式錯誤，將使用當前時間")
            timestamp = None
    
    # 插入資料庫
    try:
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        
        if timestamp:
            cursor.execute(
                "INSERT INTO price_history (game_name, price, timestamp) VALUES (?, ?, ?)",
                (game_name, price, timestamp)
            )
        else:
            cursor.execute(
                "INSERT INTO price_history (game_name, price) VALUES (?, ?)",
                (game_name, price)
            )
        
        conn.commit()
        conn.close()
        
        print(f"成功插入價格記錄:")
        print(f"   遊戲: {game_name}")
        print(f"   價格: NT$ {price}")
        print(f"   時間: {timestamp if timestamp else '當前時間'}")
        
    except Exception as e:
        print(f"插入失敗: {e}")

def view_price_records():
    """查看價格記錄"""
    print("\n查看價格記錄")
    print("-" * 30)
    
    try:
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        
        # 顯示統計資訊
        cursor.execute("SELECT COUNT(*) FROM price_history")
        total_records = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(DISTINCT game_name) FROM price_history")
        unique_games = cursor.fetchone()[0]
        
        print(f"總記錄數: {total_records}")
        print(f"不同遊戲數: {unique_games}")
        print()
        
        # 顯示最近的記錄
        cursor.execute("""
            SELECT game_name, price, timestamp 
            FROM price_history 
            ORDER BY timestamp DESC 
            LIMIT 10
        """)
        
        recent_records = cursor.fetchall()
        
        if recent_records:
            print("最近 10 筆記錄:")
            print("-" * 50)
            for game, price, timestamp in recent_records:
                print(f"{timestamp} | {game:<20} | NT$ {price}")
        else:
            print("目前沒有價格記錄")
        
        conn.close()
        
    except Exception as e:
        print(f"查看記錄失敗: {e}")

def manage_tracked_games():
    """管理收藏遊戲"""
    print("\n管理收藏遊戲")
    print("-" * 30)
    
    try:
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        
        # 顯示現有收藏
        cursor.execute("SELECT game_name FROM tracked_games ORDER BY game_name")
        tracked = cursor.fetchall()
        
        if tracked:
            print("目前收藏的遊戲:")
            for i, (game,) in enumerate(tracked, 1):
                print(f"  {i}. {game}")
            print()
        else:
            print("目前沒有收藏的遊戲")
            print()
        
        action = input("請選擇操作 (1=新增收藏, 2=移除收藏, 其他=返回): ").strip()
        
        if action == "1":
            game_name = input("請輸入要收藏的遊戲名稱: ").strip()
            if game_name:
                try:
                    cursor.execute("INSERT INTO tracked_games (game_name) VALUES (?)", (game_name,))
                    conn.commit()
                    print(f"已收藏 '{game_name}'")
                except sqlite3.IntegrityError:
                    print(f"'{game_name}' 已經在收藏列表中")
                except Exception as e:
                    print(f"收藏失敗: {e}")
        
        elif action == "2" and tracked:
            try:
                index = int(input("請輸入要移除的遊戲編號: ")) - 1
                if 0 <= index < len(tracked):
                    game_name = tracked[index][0]
                    cursor.execute("DELETE FROM tracked_games WHERE game_name = ?", (game_name,))
                    conn.commit()
                    print(f"已移除收藏 '{game_name}'")
                else:
                    print("無效的編號")
            except ValueError:
                print("請輸入有效的數字")
            except Exception as e:
                print(f"移除失敗: {e}")
        
        conn.close()
        
    except Exception as e:
        print(f"管理收藏失敗: {e}")

def view_game_history():
    """查看遊戲價格歷史"""
    print("\n查看遊戲價格歷史")
    print("-" * 30)
    
    game_name = input("請輸入遊戲名稱: ").strip()
    if not game_name:
        print("遊戲名稱不能為空")
        return
    
    try:
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT price, timestamp 
            FROM price_history 
            WHERE game_name = ? 
            ORDER BY timestamp
        """, (game_name,))
        
        history = cursor.fetchall()
        
        if history:
            print(f"\n'{game_name}' 的價格歷史:")
            print("-" * 40)
            
            min_price = min(price for price, _ in history)
            max_price = max(price for price, _ in history)
            latest_price = history[-1][0]
            
            print(f"統計資訊:")
            print(f"   最低價格: NT$ {min_price}")
            print(f"   最高價格: NT$ {max_price}")
            print(f"   最新價格: NT$ {latest_price}")
            print(f"   記錄數量: {len(history)} 筆")
            print()
            
            print("詳細記錄:")
            for price, timestamp in history:
                print(f"   {timestamp} - NT$ {price}")
        else:
            print(f"找不到 '{game_name}' 的價格記錄")
        
        conn.close()
        
    except Exception as e:
        print(f"查看歷史失敗: {e}")

def batch_import_prices():
    """批量導入價格資料"""
    print("\n批量導入價格資料")
    print("-" * 30)
    print("格式說明: 遊戲名稱,價格,時間(可選)")
    print("範例: Cyberpunk 2077,1790,2024-01-15 14:30")
    print("或: Portal 2,268")
    print()
    
    filename = input("請輸入 CSV 檔案路徑 (或直接輸入資料，每行一筆): ").strip()
    
    if filename and filename.endswith('.csv'):
        # 從檔案讀取
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                lines = f.readlines()
        except FileNotFoundError:
            print(f"找不到檔案: {filename}")
            return
        except Exception as e:
            print(f"讀取檔案失敗: {e}")
            return
    else:
        # 手動輸入
        print("請輸入資料 (每行一筆，空行結束):")
        lines = []
        while True:
            line = input().strip()
            if not line:
                break
            lines.append(line)
    
    if not lines:
        print("沒有資料可導入")
        return
    
    # 解析並導入資料
    success_count = 0
    error_count = 0
    
    try:
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        
        for i, line in enumerate(lines, 1):
            try:
                parts = [p.strip() for p in line.strip().split(',')]
                if len(parts) < 2:
                    print(f"第 {i} 行格式錯誤: {line}")
                    error_count += 1
                    continue
                
                game_name = parts[0]
                price = float(parts[1])
                timestamp = parts[2] if len(parts) > 2 else None
                
                if timestamp:
                    # 驗證時間格式
                    datetime.strptime(timestamp, "%Y-%m-%d %H:%M")
                    cursor.execute(
                        "INSERT INTO price_history (game_name, price, timestamp) VALUES (?, ?, ?)",
                        (game_name, price, timestamp + ":00")
                    )
                else:
                    cursor.execute(
                        "INSERT INTO price_history (game_name, price) VALUES (?, ?)",
                        (game_name, price)
                    )
                
                success_count += 1
                
            except ValueError as e:
                print(f"第 {i} 行資料錯誤: {line} ({e})")
                error_count += 1
            except Exception as e:
                print(f"第 {i} 行處理失敗: {line} ({e})")
                error_count += 1
        
        conn.commit()
        conn.close()
        
        print(f"\n導入完成:")
        print(f"   成功: {success_count} 筆")
        print(f"   失敗: {error_count} 筆")
        
    except Exception as e:
        print(f"批量導入失敗: {e}")

def main():
    """主要執行函數"""
    while True:
        show_menu()
        
        choice = input("請選擇功能 (1-8): ").strip()
        
        if choice == "1":
            insert_manual_price()
        elif choice == "2":
            view_price_records()
        elif choice == "3":
            manage_tracked_games()
        elif choice == "4":
            print("刪除功能尚未實作")
        elif choice == "5":
            view_game_history()
        elif choice == "6":
            batch_import_prices()
        elif choice == "7":
            print("匯出功能尚未實作")
        elif choice == "8":
            print("再見！")
            break
        else:
            print("無效選擇，請重新輸入")
        
        input("\n按 Enter 繼續...")

if __name__ == "__main__":
    main()
