#!/usr/bin/env python
# -*- coding: utf-8 -*-

import sys
import os

# 確保我們在正確的目錄
print("當前工作目錄:", os.getcwd())
print("Python 版本:", sys.version)

try:
    # 測試導入
    from flask import Flask
    print("✓ Flask 導入成功")
    
    import db
    print("✓ db 模組導入成功")
    
    from bs4 import BeautifulSoup
    print("✓ BeautifulSoup 導入成功")
    
    # 初始化資料庫
    db.init_db()
    print("✓ 資料庫初始化成功")
    
    # 測試導入 app
    import app
    print("✓ app.py 導入成功")
    
    print("\n" + "="*50)
    print("所有測試通過！應用程式應該可以正常啟動")
    print("請執行: python app.py")
    print("然後在瀏覽器開啟: http://127.0.0.1:5000")
    print("="*50)
    
except Exception as e:
    print(f"✗ 錯誤: {e}")
    import traceback
    traceback.print_exc()
