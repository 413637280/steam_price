# Steam 價格追蹤器

這是一個功能完整的 Steam 遊戲價格追蹤網站，支援價格監控、歷史紀錄和智能提醒。

## 新功能特色

### 核心功能
- 智能價格查詢 - 支援遊戲名稱和 AppID 查詢
- 價格歷史圖表 - 互動式價格變化趨勢圖
- 價格提醒系統 - 設定目標價格自動提醒
- 收藏管理 - 收藏和移除感興趣的遊戲
- 個人儀表板 - 統一管理所有價格監控

### 用戶功能
- 用戶系統 - 註冊/登入/登出
- 批量更新 - 一鍵更新所有收藏遊戲價格
- 響應式設計 - 支援手機和桌面瀏覽

## 安裝與啟動

### 1. 安裝依賴套件
```bash
pip install flask beautifulsoup4 requests selenium webdriver-manager
```

### 2. 啟動應用程式
選擇以下任一方式：

**方式 A: 直接執行**
```bash
cd steam-price-tracker
python app.py
```

**方式 B: 使用 Flask CLI**
```bash
set FLASK_APP=app.py
flask run
```

**方式 C: 使用批次檔案**
```bash
# Windows 命令提示字元
start.bat

# PowerShell
.\start.ps1
```

### 3. 開啟瀏覽器
訪問：http://127.0.0.1:5000

## 使用說明

### 基本查詢
1. 在首頁輸入遊戲名稱或 AppID
2. 點擊「查詢」獲取當前價格
3. 選擇「收藏」將遊戲加入追蹤列表

### 價格提醒（需登入）
1. 查詢遊戲後，設定「目標價格」
2. 點擊「設定提醒」
3. 在儀表板中管理所有提醒

### 價格歷史
1. 在收藏列表中點擊「📈 查看價格歷史」
2. 瀏覽互動式價格變化圖表
3. 查看詳細的價格記錄表格

### 個人儀表板
1. 登入後點擊「📊 儀表板」
2. 查看所有價格提醒設定
3. 監控收藏遊戲的價格概覽
4. 比較當前價格與歷史最低價

## 專案結構

```
steam-price-tracker/
├── app.py              # 主應用程式
├── db.py               # 資料庫操作
├── requirements.txt    # 依賴套件
├── start.bat          # Windows 啟動腳本
├── start.ps1          # PowerShell 啟動腳本
├── test_imports.py    # 導入測試腳本
├── templates/         # HTML 模板
│   ├── index.html     # 首頁
│   ├── dashboard.html # 儀表板
│   ├── history.html   # 價格歷史
│   ├── login.html     # 登入頁面
│   └── register.html  # 註冊頁面
└── static/
    └── style.css      # 樣式檔案
```

## 技術架構

- **後端**: Python Flask
- **前端**: Bootstrap 5 + Chart.js
- **爬蟲**: Selenium + BeautifulSoup
- **資料庫**: SQLite
- **圖表**: Chart.js

## 故障排除

### 導入錯誤
```bash
python test_imports.py
```

### 編碼問題
確保所有檔案使用 UTF-8 編碼儲存。

### Chrome WebDriver
首次執行時會自動下載 ChromeDriver，請確保網路連線正常。

## 更新日誌

### v2.0 新功能
- 移除收藏功能
- 價格歷史圖表
- 價格提醒系統
- 批量更新功能
- 個人儀表板
- 響應式設計改善

---

**提示**: 首次使用建議先註冊帳號，這樣就能使用價格提醒和儀表板等進階功能！
