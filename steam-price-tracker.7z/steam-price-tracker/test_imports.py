#!/usr/bin/env python
# -*- coding: utf-8 -*-

print("正在測試導入...")

try:
    from flask import Flask
    print("✓ Flask 導入成功")
except ImportError as e:
    print(f"✗ Flask 導入失敗: {e}")

try:
    import db
    print("✓ db 模組導入成功")
except ImportError as e:
    print(f"✗ db 模組導入失敗: {e}")

try:
    from bs4 import BeautifulSoup
    print("✓ BeautifulSoup 導入成功")
except ImportError as e:
    print(f"✗ BeautifulSoup 導入失敗: {e}")

print("\n測試完成！現在可以啟動應用程式。")
print("請手動在命令列中執行:")
print("python app.py")
print("然後瀏覽器開啟: http://127.0.0.1:5000")
