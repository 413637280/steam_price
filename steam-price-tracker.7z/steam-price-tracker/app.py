from bs4 import BeautifulSoup
from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash
import db
from collections import deque

import hashlib
app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# 初始化 users 資料表
def init_user_db():
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT
    )
    """)
    # 新增價格提醒表
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS price_alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        game_name TEXT,
        target_price REAL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(username, game_name)
    )
    """)
    conn.commit()
    conn.close()

init_user_db()

# 初始化主要資料庫表格
db.init_db()

# 註冊
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if not username or not password:
            flash('請輸入帳號和密碼')
            return redirect(url_for('register'))
        pw_hash = hashlib.sha256(password.encode()).hexdigest()
        import sqlite3
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, pw_hash))
            conn.commit()
            flash('註冊成功，請登入')
            return redirect(url_for('login'))
        except Exception as e:
            flash('帳號已存在或資料庫錯誤')
            return redirect(url_for('register'))
        finally:
            conn.close()
    return render_template('register.html')

# 登入
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        pw_hash = hashlib.sha256(password.encode()).hexdigest()
        import sqlite3
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username=? AND password=?", (username, pw_hash))
        user = cursor.fetchone()
        conn.close()
        if user:
            session['user'] = username
            flash('登入成功')
            return redirect(url_for('index'))
        else:
            flash('帳號或密碼錯誤')
            return redirect(url_for('login'))
    return render_template('login.html')

# 登出
@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('已登出')
    return redirect(url_for('index'))

# 以 appid 查詢 SteamDB 台灣區價格
def get_steamdb_price(appid):
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
    from webdriver_manager.chrome import ChromeDriverManager
    import time
    from bs4 import BeautifulSoup

    url = f"https://steamdb.info/app/{appid}/"
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--disable-gpu')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--window-size=1920,1080')
    chrome_options.add_argument('--disable-blink-features=AutomationControlled')
    chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Safari/537.36')

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    driver.get(url)
    time.sleep(5)
    html = driver.page_source
    driver.quit()

    soup = BeautifulSoup(html, "html.parser")
    tw_row = soup.select_one('tr.price-table__row[data-country="TW"]')
    price = "查無價格"
    if tw_row:
        price_cell = tw_row.select_one('td.price-table__price')
        if price_cell:
            price = price_cell.text.strip()
    return price

def get_tracked_games():
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    cursor.execute("SELECT game_name FROM tracked_games ORDER BY id DESC")
    games = [row[0] for row in cursor.fetchall()]
    conn.close()
    return games

# 用 deque 儲存最近查詢紀錄（最多 10 筆）
recent_queries = deque(maxlen=10)

def get_steam_price(game_name):
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.common.by import By
    from selenium.webdriver.chrome.options import Options
    from webdriver_manager.chrome import ChromeDriverManager
    import time

    search_url = f"https://store.steampowered.com/search/?term={game_name}"
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--disable-gpu')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--window-size=1920,1080')
    chrome_options.add_argument('--disable-blink-features=AutomationControlled')
    chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Safari/537.36')

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    driver.get(search_url)
    time.sleep(5)
    html = driver.page_source
    driver.quit()

    soup = BeautifulSoup(html, "html.parser")
    game_item = soup.select_one("a.search_result_row")
    if not game_item:
        with open("steam_search_debug.html", "w", encoding="utf-8") as f:
            f.write(html)
        return {"name": game_name, "current_price": "查無價格"}
    name = game_item.select_one(".title").text.strip()
    price = "查無價格"
    discount_price = game_item.select_one(".search_price.discounted")
    if discount_price:
        price = discount_price.text.strip().replace('NT$','').replace(',','').strip()
    else:
        normal_price = game_item.select_one(".search_price")
        if normal_price:
            price = normal_price.text.strip().replace('NT$','').replace(',','').strip()
    try:
        if price.replace('.', '', 1).isdigit():
            db.insert_price(name, price)
    except Exception as e:
        print(f"DB insert error: {e}")
    return {"name": name, "current_price": f"NT$ {price}"}

@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    tracked = get_tracked_games()
    steamdb_price = None
    user = session.get('user')
    if request.method == 'POST':
        game_name = request.form.get('query')
        appid = request.form.get('appid')
        if appid:
            steamdb_price = get_steamdb_price(appid)
            result = {"name": f"AppID {appid}", "current_price": steamdb_price}
        elif game_name:
            result = get_steam_price(game_name)
            recent_queries.appendleft(result['name'])
    return render_template('index.html', result=result, tracked=tracked, recent=list(recent_queries), steamdb_price=steamdb_price, user=user)

@app.route('/api/price', methods=['GET'])
def api_price():
    game_name = request.args.get('game')
    if not game_name:
        return jsonify({'error': 'Missing game parameter'}), 400
    result = get_steam_price(game_name)
    return jsonify(result)

@app.route('/api/steamdb_price', methods=['GET'])
def api_steamdb_price():
    appid = request.args.get('appid')
    if not appid:
        return jsonify({'error': 'Missing appid parameter'}), 400
    price = get_steamdb_price(appid)
    return jsonify({'appid': appid, 'steamdb_price': price})

# 收藏遊戲
@app.route('/track', methods=['POST'])
def track():
    game_name = request.form.get('game_name')
    if not game_name:
        flash('未提供遊戲名稱')
        return redirect(url_for('index'))
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO tracked_games (game_name) VALUES (?)", (game_name,))
        conn.commit()
        flash(f'已收藏 {game_name}')
    except Exception as e:
        flash('收藏失敗或已存在')
    finally:
        conn.close()
    return redirect(url_for('index'))

# 移除收藏
@app.route('/untrack', methods=['POST'])
def untrack():
    game_name = request.form.get('game_name')
    if not game_name:
        flash('未提供遊戲名稱')
        return redirect(url_for('index'))
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM tracked_games WHERE game_name = ?", (game_name,))
        conn.commit()
        flash(f'已移除收藏 {game_name}')
    except Exception as e:
        flash('移除失敗')
    finally:
        conn.close()
    return redirect(url_for('index'))

# 查看價格歷史
@app.route('/history/<game_name>')
def price_history(game_name):
    price_data = db.get_prices(game_name)
    return render_template('history.html', game_name=game_name, price_data=price_data)

# API: 獲取價格歷史數據 (用於圖表)
@app.route('/api/history/<game_name>')
def api_price_history(game_name):
    price_data = db.get_prices(game_name)
    return jsonify(price_data)

# 批量查詢收藏遊戲價格
@app.route('/refresh_all', methods=['POST'])
def refresh_all():
    tracked_games = get_tracked_games()
    updated_count = 0
    for game_name in tracked_games:
        try:
            result = get_steam_price(game_name)
            if "查無價格" not in result['current_price']:
                updated_count += 1
        except Exception as e:
            print(f"Error updating {game_name}: {e}")
    flash(f'已更新 {updated_count} 個遊戲價格')
    return redirect(url_for('index'))

# 設定價格提醒
@app.route('/set_alert', methods=['POST'])
def set_alert():
    game_name = request.form.get('game_name')
    target_price = request.form.get('target_price')
    user = session.get('user')
    
    if not user:
        flash('請先登入')
        return redirect(url_for('login'))
    
    if not game_name or not target_price:
        flash('請提供遊戲名稱和目標價格')
        return redirect(url_for('index'))
    
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT OR REPLACE INTO price_alerts (username, game_name, target_price) 
            VALUES (?, ?, ?)
        """, (user, game_name, float(target_price)))
        conn.commit()
        flash(f'已設定 {game_name} 的價格提醒：NT$ {target_price}')
    except Exception as e:
        flash('設定提醒失敗')
    finally:
        conn.close()
    return redirect(url_for('index'))

# 獲取最低價格歷史
def get_lowest_price(game_name):
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    cursor.execute("SELECT MIN(price) FROM price_history WHERE game_name = ?", (game_name,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result and result[0] else None

# 個人儀表板
@app.route('/dashboard')
def dashboard():
    user = session.get('user')
    if not user:
        flash('請先登入')
        return redirect(url_for('login'))
    
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    
    # 獲取用戶的價格提醒
    cursor.execute("SELECT game_name, target_price FROM price_alerts WHERE username = ?", (user,))
    alerts = cursor.fetchall()
    
    # 獲取收藏遊戲的最新價格
    tracked_games = get_tracked_games()
    game_prices = []
    for game in tracked_games:
        cursor.execute("""
            SELECT price, timestamp FROM price_history 
            WHERE game_name = ? 
            ORDER BY timestamp DESC LIMIT 1
        """, (game,))
        latest = cursor.fetchone()
        
        lowest = get_lowest_price(game)
        
        game_prices.append({
            'name': game,
            'current_price': latest[0] if latest else None,
            'lowest_price': lowest,
            'last_updated': latest[1] if latest else None
        })
    
    conn.close()
    return render_template('dashboard.html', user=user, alerts=alerts, game_prices=game_prices)

# 移除價格提醒
@app.route('/remove_alert', methods=['POST'])
def remove_alert():
    game_name = request.form.get('game_name')
    user = session.get('user')
    
    if not user:
        return jsonify({'error': 'Not logged in'}), 401
    
    if not game_name:
        return jsonify({'error': 'Missing game name'}), 400
    
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM price_alerts WHERE username = ? AND game_name = ?", (user, game_name))
        conn.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

# 診斷頁面 - 檢查所有功能
@app.route('/debug')
def debug():
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    
    # 檢查所有表格
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [row[0] for row in cursor.fetchall()]
    
    # 檢查 tracked_games 表格內容
    cursor.execute("SELECT * FROM tracked_games")
    tracked_games = cursor.fetchall()
    
    # 檢查 price_alerts 表格內容
    try:
        cursor.execute("SELECT * FROM price_alerts")
        price_alerts = cursor.fetchall()
    except:
        price_alerts = "表格不存在"
    
    # 檢查 users 表格內容
    try:
        cursor.execute("SELECT username FROM users")
        users = [row[0] for row in cursor.fetchall()]
    except:
        users = "表格不存在"
    
    conn.close()
    
    return f"""
    <!DOCTYPE html>
    <html lang="zh-Hant">
    <head>
        <meta charset="UTF-8">
        <title>系統診斷</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light">
    <div class="container py-5">
        <h1>系統診斷資訊</h1>
        
        <div class="card mb-3">
            <div class="card-header"><h5>應用版本</h5></div>
            <div class="card-body">
                <p><strong>版本:</strong> v2.0 - 包含新功能</p>
                <p><strong>當前登入用戶:</strong> {session.get('user', '未登入')}</p>
            </div>
        </div>
        
        <div class="card mb-3">
            <div class="card-header"><h5>資料庫表格</h5></div>
            <div class="card-body">
                <ul>{''.join([f'<li>{table}</li>' for table in tables])}</ul>
            </div>
        </div>
        
        <div class="card mb-3">
            <div class="card-header"><h5>收藏遊戲</h5></div>
            <div class="card-body">
                <p>{tracked_games if tracked_games else '無收藏遊戲'}</p>
            </div>
        </div>
        
        <div class="card mb-3">
            <div class="card-header"><h5>價格提醒</h5></div>
            <div class="card-body">
                <p>{price_alerts if price_alerts != "表格不存在" else '表格不存在或無提醒'}</p>
            </div>
        </div>
        
        <div class="card mb-3">
            <div class="card-header"><h5>用戶列表</h5></div>
            <div class="card-body">
                <p>{users if users != "表格不存在" else '表格不存在或無用戶'}</p>
            </div>
        </div>
        
        <div class="card mb-3">
            <div class="card-header"><h5>功能測試</h5></div>
            <div class="card-body">
                <h6>測試收藏功能:</h6>
                <form method="post" action="/track" class="mb-3">
                    <div class="input-group">
                        <input type="text" name="game_name" class="form-control" placeholder="輸入遊戲名稱測試收藏" value="測試遊戲">
                        <button type="submit" class="btn btn-warning">測試收藏</button>
                    </div>
                </form>
                
                <h6>快速搜尋測試:</h6>
                <form method="post" action="/" class="mb-3">
                    <div class="input-group">
                        <input type="text" name="query" class="form-control" value="Cyberpunk 2077">
                        <button type="submit" class="btn btn-primary">測試搜尋</button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="text-center">
            <a href="/" class="btn btn-success">返回首頁</a>
            {'<a href="/dashboard" class="btn btn-info ms-2">儀表板</a>' if session.get('user') else '<a href="/login" class="btn btn-outline-primary ms-2">登入</a>'}
        </div>
    </div>
    </body>
    </html>
    """

# 測試搜尋功能 - 返回固定結果以便測試收藏按鈕
@app.route('/test_search')
def test_search():
    # 模擬一個搜尋結果
    result = {'name': 'Cyberpunk 2077', 'current_price': 'NT$ 1,790'}
    tracked = get_tracked_games()
    user = session.get('user')
    return render_template('index.html', result=result, tracked=tracked, recent=[], user=user)

if __name__ == '__main__':
    app.secret_key = 'your_secret_key_here'
    app.run(debug=True)
