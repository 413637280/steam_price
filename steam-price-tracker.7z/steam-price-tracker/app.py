from bs4 import BeautifulSoup
from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash
import db
from collections import deque

import hashlib
app = Flask(__name__)
app.secret_key = 'your_secret_key_here'

# 初始化 users 資料表
def init_user_db():
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE,
        password TEXT
    )
    """)
    # 新增價格提醒表
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS price_alerts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        game_name TEXT,
        target_price REAL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(username, game_name)
    )
    """)
    conn.commit()
    conn.close()

init_user_db()

# 初始化主要資料庫表格
db.init_db()

# 註冊
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        if not username or not password:
            flash('請輸入帳號和密碼')
            return redirect(url_for('register'))
        pw_hash = hashlib.sha256(password.encode()).hexdigest()
        import sqlite3
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        try:
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, pw_hash))
            conn.commit()
            flash('註冊成功，請登入')
            return redirect(url_for('login'))
        except Exception as e:
            flash('帳號已存在或資料庫錯誤')
            return redirect(url_for('register'))
        finally:
            conn.close()
    return render_template('register.html')

# 登入
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        pw_hash = hashlib.sha256(password.encode()).hexdigest()
        import sqlite3
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username=? AND password=?", (username, pw_hash))
        user = cursor.fetchone()
        conn.close()
        if user:
            session['user'] = username
            flash('登入成功')
            return redirect(url_for('index'))
        else:
            flash('帳號或密碼錯誤')
            return redirect(url_for('login'))
    return render_template('login.html')

# 登出
@app.route('/logout')
def logout():
    session.pop('user', None)
    flash('已登出')
    return redirect(url_for('index'))

# 以 appid 查詢 SteamDB 台灣區價格
def get_steamdb_price(appid):
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
    from webdriver_manager.chrome import ChromeDriverManager
    import time
    from bs4 import BeautifulSoup

    url = f"https://steamdb.info/app/{appid}/"
    chrome_options = Options()
    chrome_options.add_argument('--headless')
    chrome_options.add_argument('--disable-gpu')
    chrome_options.add_argument('--no-sandbox')
    chrome_options.add_argument('--window-size=1920,1080')
    chrome_options.add_argument('--disable-blink-features=AutomationControlled')
    chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Safari/537.36')

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    driver.get(url)
    time.sleep(5)
    html = driver.page_source
    driver.quit()

    soup = BeautifulSoup(html, "html.parser")
    tw_row = soup.select_one('tr.price-table__row[data-country="TW"]')
    price = "查無價格"
    if tw_row:
        price_cell = tw_row.select_one('td.price-table__price')
        if price_cell:
            price = price_cell.text.strip()
    return price

def get_tracked_games():
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    cursor.execute("SELECT game_name FROM tracked_games ORDER BY id DESC")
    games = [row[0] for row in cursor.fetchall()]
    conn.close()
    return games

# 用 deque 儲存最近查詢紀錄（最多 10 筆）
recent_queries = deque(maxlen=10)

def get_steam_price(game_name):
    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.service import Service
        from selenium.webdriver.common.by import By
        from selenium.webdriver.chrome.options import Options
        from webdriver_manager.chrome import ChromeDriverManager
        import time
        import os

        print(f"開始查詢遊戲: {game_name}")
        
        search_url = f"https://store.steampowered.com/search/?term={game_name}"
        chrome_options = Options()
        chrome_options.add_argument('--headless')
        chrome_options.add_argument('--disable-gpu')
        chrome_options.add_argument('--no-sandbox')
        chrome_options.add_argument('--disable-dev-shm-usage')
        chrome_options.add_argument('--window-size=1920,1080')
        chrome_options.add_argument('--disable-blink-features=AutomationControlled')
        chrome_options.add_argument('--disable-extensions')
        chrome_options.add_argument('--disable-plugins')
        chrome_options.add_argument('--disable-images')
        chrome_options.add_argument('--disable-javascript')
        chrome_options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0 Safari/537.36')
        
        # Docker 環境中的額外設定
        if os.getenv('DISPLAY'):
            chrome_options.add_argument(f'--display={os.getenv("DISPLAY")}')

        print("正在啟動 Chrome WebDriver...")
        
        try:
            # 在 Docker 中使用系統安裝的 Chrome
            service = Service('/usr/bin/chromedriver') if os.path.exists('/usr/bin/chromedriver') else Service(ChromeDriverManager().install())
            driver = webdriver.Chrome(service=service, options=chrome_options)
        except Exception as e:
            print(f"使用預設 ChromeDriver: {e}")
            driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
        
        print(f"正在訪問 URL: {search_url}")
        driver.get(search_url)
        time.sleep(8)  # 增加等待時間
        
        html = driver.page_source
        driver.quit()
        print("WebDriver 關閉完成")

        soup = BeautifulSoup(html, "html.parser")
        game_item = soup.select_one("a.search_result_row")
        
        if not game_item:
            print("未找到遊戲項目，保存 HTML 用於調試")
            with open("steam_search_debug.html", "w", encoding="utf-8") as f:
                f.write(html)
            return {"name": game_name, "current_price": "查無價格", "error": "未找到搜尋結果"}
        
        name_element = game_item.select_one(".title")
        if not name_element:
            print("未找到遊戲名稱元素")
            return {"name": game_name, "current_price": "查無價格", "error": "未找到遊戲名稱"}
            
        name = name_element.text.strip()
        print(f"找到遊戲: {name}")
        
        price = "查無價格"
        discount_price = game_item.select_one(".search_price.discounted")
        if discount_price:
            price_text = discount_price.text.strip()
            print(f"找到折扣價格: {price_text}")
            price = price_text.replace('NT$','').replace(',','').strip()
        else:
            normal_price = game_item.select_one(".search_price")
            if normal_price:
                price_text = normal_price.text.strip()
                print(f"找到正常價格: {price_text}")
                price = price_text.replace('NT$','').replace(',','').strip()
        
        print(f"最終價格: {price}")
        
        # 嘗試保存到資料庫
        try:
            if price != "查無價格" and price.replace('.', '', 1).isdigit():
                db.insert_price(name, price)
                print("價格已保存到資料庫")
        except Exception as e:
            print(f"DB insert error: {e}")
        
        return {"name": name, "current_price": f"NT$ {price}"}
        
    except Exception as e:
        print(f"查詢價格時發生錯誤: {str(e)}")
        import traceback
        traceback.print_exc()
        return {"name": game_name, "current_price": "查詢失敗", "error": str(e)}

@app.route('/', methods=['GET', 'POST'])
def index():
    result = None
    tracked = get_tracked_games()
    steamdb_price = None
    user = session.get('user')
    if request.method == 'POST':
        game_name = request.form.get('query')
        appid = request.form.get('appid')
        if appid:
            steamdb_price = get_steamdb_price(appid)
            result = {"name": f"AppID {appid}", "current_price": steamdb_price}
        elif game_name:
            result = get_steam_price(game_name)
            recent_queries.appendleft(result['name'])
    return render_template('index.html', result=result, tracked=tracked, recent=list(recent_queries), steamdb_price=steamdb_price, user=user)

@app.route('/api/price', methods=['GET'])
def api_price():
    game_name = request.args.get('game')
    if not game_name:
        return jsonify({'error': 'Missing game parameter'}), 400
    result = get_steam_price(game_name)
    return jsonify(result)

@app.route('/api/steamdb_price', methods=['GET'])
def api_steamdb_price():
    appid = request.args.get('appid')
    if not appid:
        return jsonify({'error': 'Missing appid parameter'}), 400
    price = get_steamdb_price(appid)
    return jsonify({'appid': appid, 'steamdb_price': price})

# 收藏遊戲
@app.route('/track', methods=['POST'])
def track():
    game_name = request.form.get('game_name')
    if not game_name:
        flash('未提供遊戲名稱')
        return redirect(url_for('index'))
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO tracked_games (game_name) VALUES (?)", (game_name,))
        conn.commit()
        flash(f'已收藏 {game_name}')
    except Exception as e:
        flash('收藏失敗或已存在')
    finally:
        conn.close()
    return redirect(url_for('index'))

# 移除收藏
@app.route('/untrack', methods=['POST'])
def untrack():
    game_name = request.form.get('game_name')
    if not game_name:
        flash('未提供遊戲名稱')
        return redirect(url_for('index'))
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM tracked_games WHERE game_name = ?", (game_name,))
        conn.commit()
        flash(f'已移除收藏 {game_name}')
    except Exception as e:
        flash('移除失敗')
    finally:
        conn.close()
    return redirect(url_for('index'))

# 查看價格歷史
@app.route('/history/<game_name>')
def price_history(game_name):
    price_data = db.get_prices(game_name)
    return render_template('history.html', game_name=game_name, price_data=price_data)

# API: 獲取價格歷史數據 (用於圖表)
@app.route('/api/history/<game_name>')
def api_price_history(game_name):
    price_data = db.get_prices(game_name)
    return jsonify(price_data)

# 批量查詢收藏遊戲價格
@app.route('/refresh_all', methods=['POST'])
def refresh_all():
    tracked_games = get_tracked_games()
    updated_count = 0
    for game_name in tracked_games:
        try:
            result = get_steam_price(game_name)
            if "查無價格" not in result['current_price']:
                updated_count += 1
        except Exception as e:
            print(f"Error updating {game_name}: {e}")
    flash(f'已更新 {updated_count} 個遊戲價格')
    return redirect(url_for('index'))

# 設定價格提醒
@app.route('/set_alert', methods=['POST'])
def set_alert():
    game_name = request.form.get('game_name')
    target_price = request.form.get('target_price')
    user = session.get('user')
    
    if not user:
        flash('請先登入')
        return redirect(url_for('login'))
    
    if not game_name or not target_price:
        flash('請提供遊戲名稱和目標價格')
        return redirect(url_for('index'))
    
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    try:
        cursor.execute("""
            INSERT OR REPLACE INTO price_alerts (username, game_name, target_price) 
            VALUES (?, ?, ?)
        """, (user, game_name, float(target_price)))
        conn.commit()
        flash(f'已設定 {game_name} 的價格提醒：NT$ {target_price}')
    except Exception as e:
        flash('設定提醒失敗')
    finally:
        conn.close()
    return redirect(url_for('index'))

# 獲取最低價格歷史
def get_lowest_price(game_name):
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    cursor.execute("SELECT MIN(price) FROM price_history WHERE game_name = ?", (game_name,))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result and result[0] else None

# 個人儀表板
@app.route('/dashboard')
def dashboard():
    user = session.get('user')
    if not user:
        flash('請先登入')
        return redirect(url_for('login'))
    
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    
    # 獲取用戶的價格提醒
    cursor.execute("SELECT game_name, target_price FROM price_alerts WHERE username = ?", (user,))
    alerts = cursor.fetchall()
    
    # 獲取收藏遊戲的最新價格
    tracked_games = get_tracked_games()
    game_prices = []
    for game in tracked_games:
        cursor.execute("""
            SELECT price, timestamp FROM price_history 
            WHERE game_name = ? 
            ORDER BY timestamp DESC LIMIT 1
        """, (game,))
        latest = cursor.fetchone()
        
        lowest = get_lowest_price(game)
        
        game_prices.append({
            'name': game,
            'current_price': latest[0] if latest else None,
            'lowest_price': lowest,
            'last_updated': latest[1] if latest else None
        })
    
    conn.close()
    return render_template('dashboard.html', user=user, alerts=alerts, game_prices=game_prices)

# 移除價格提醒
@app.route('/remove_alert', methods=['POST'])
def remove_alert():
    game_name = request.form.get('game_name')
    user = session.get('user')
    
    if not user:
        return jsonify({'error': 'Not logged in'}), 401
    
    if not game_name:
        return jsonify({'error': 'Missing game name'}), 400
    
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    try:
        cursor.execute("DELETE FROM price_alerts WHERE username = ? AND game_name = ?", (user, game_name))
        conn.commit()
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'error': str(e)}), 500
    finally:
        conn.close()

# 診斷頁面 - 檢查所有功能
@app.route('/debug')
def debug():
    import sqlite3
    conn = sqlite3.connect("prices.db")
    cursor = conn.cursor()
    
    # 檢查所有表格
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [row[0] for row in cursor.fetchall()]
    
    # 檢查 tracked_games 表格內容
    cursor.execute("SELECT * FROM tracked_games")
    tracked_games = cursor.fetchall()
    
    # 檢查 price_alerts 表格內容
    try:
        cursor.execute("SELECT * FROM price_alerts")
        price_alerts = cursor.fetchall()
    except:
        price_alerts = "表格不存在"
    
    # 檢查 users 表格內容
    try:
        cursor.execute("SELECT username FROM users")
        users = [row[0] for row in cursor.fetchall()]
    except:
        users = "表格不存在"
    
    # 檢查資料庫統計
    db_stats = {}
    for table in tables:
        try:
            cursor.execute(f"SELECT COUNT(*) FROM {table}")
            count = cursor.fetchone()[0]
            db_stats[table] = count
        except:
            db_stats[table] = "錯誤"
    
    conn.close()
    
    return f"""
    <!DOCTYPE html>
    <html lang="zh-Hant">
    <head>
        <meta charset="UTF-8">
        <title>系統診斷</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light">
    <div class="container py-5">
        <h1>系統診斷資訊</h1>
        
        <div class="card mb-3">
            <div class="card-header"><h5>應用版本</h5></div>
            <div class="card-body">
                <p><strong>版本:</strong> v2.1 - 包含資料庫管理功能</p>
                <p><strong>當前登入用戶:</strong> {session.get('user', '未登入')}</p>
                <p><strong>資料庫檔案:</strong> prices.db</p>
            </div>
        </div>
        
        <div class="card mb-3">
            <div class="card-header"><h5>資料庫表格</h5></div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>表格列表:</h6>
                        <ul>{''.join([f'<li>{table}</li>' for table in tables])}</ul>
                    </div>
                    <div class="col-md-6">
                        <h6>記錄統計:</h6>
                        <ul>{''.join([f'<li>{table}: {count} 筆</li>' for table, count in db_stats.items()])}</ul>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="card mb-3">
            <div class="card-header"><h5>收藏遊戲</h5></div>
            <div class="card-body">
                <p>{tracked_games if tracked_games else '無收藏遊戲'}</p>
            </div>
        </div>
        
        <div class="card mb-3">
            <div class="card-header"><h5>🔔 價格提醒</h5></div>
            <div class="card-body">
                <p>{price_alerts if price_alerts != "表格不存在" else '表格不存在或無提醒'}</p>
            </div>
        </div>
        
        <div class="card mb-3">
            <div class="card-header"><h5>用戶列表</h5></div>
            <div class="card-body">
                <p>{users if users != "表格不存在" else '表格不存在或無用戶'}</p>
            </div>
        </div>
        
        <div class="card mb-3">
            <div class="card-header"><h5>🧪 功能測試</h5></div>
            <div class="card-body">
                <h6>測試收藏功能:</h6>
                <form method="post" action="/track" class="mb-3">
                    <div class="input-group">
                        <input type="text" name="game_name" class="form-control" placeholder="輸入遊戲名稱測試收藏" value="測試遊戲">
                        <button type="submit" class="btn btn-warning">測試收藏</button>
                    </div>
                </form>
                
                <h6>快速搜尋測試:</h6>
                <form method="post" action="/" class="mb-3">
                    <div class="input-group">
                        <input type="text" name="query" class="form-control" value="Cyberpunk 2077">
                        <button type="submit" class="btn btn-primary">測試搜尋</button>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="text-center">
            <a href="/" class="btn btn-success">返回首頁</a>
            {'<a href="/dashboard" class="btn btn-info ms-2">儀表板</a>' if session.get('user') else '<a href="/login" class="btn btn-outline-primary ms-2">登入</a>'}
            <a href="/test_selenium" class="btn btn-secondary ms-2">測試 Selenium</a>
            <a href="/database_admin" class="btn btn-warning ms-2">資料庫管理</a>
        </div>
    </div>
    </body>
    </html>
    """

# 資料庫管理頁面
@app.route('/database_admin')
def database_admin():
    try:
        import db
        status = db.check_db_status()
        
        return f"""
        <!DOCTYPE html>
        <html lang="zh-Hant">
        <head>
            <meta charset="UTF-8">
            <title>資料庫管理</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body class="bg-light">
        <div class="container py-5">
            <h1>資料庫管理</h1>
            
            <div class="card mb-3">
                <div class="card-header"><h5>資料庫狀態</h5></div>
                <div class="card-body">
                    <p><strong>狀態:</strong> <span class="badge bg-{'success' if status['status'] == 'success' else 'danger'}">{status['status']}</span></p>
                    {'<p><strong>錯誤:</strong> ' + status.get('message', '') + '</p>' if status['status'] == 'error' else ''}
                    {f'<p><strong>表格:</strong> {", ".join(status["tables"])}</p>' if status['status'] == 'success' else ''}
                </div>
            </div>
            
            {f'''
            <div class="card mb-3">
                <div class="card-header"><h5>記錄統計</h5></div>
                <div class="card-body">
                    <div class="row">
                        {''.join([f'<div class="col-md-6 mb-2"><strong>{table}:</strong> {count} 筆記錄</div>' for table, count in status["stats"].items()])}
                    </div>
                </div>
            </div>
            ''' if status['status'] == 'success' else ''}
            
            <div class="card mb-3">
                <div class="card-header"><h5>� 手動資料管理</h5></div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>新增價格記錄:</h6>
                            <form method="post" action="/api/manual_price" class="mb-3">
                                <div class="mb-2">
                                    <input type="text" name="game_name" class="form-control" placeholder="遊戲名稱" required>
                                </div>
                                <div class="mb-2">
                                    <input type="number" name="price" class="form-control" placeholder="價格 (例: 1790)" step="0.01" min="0" required>
                                </div>
                                <div class="mb-2">
                                    <input type="datetime-local" name="custom_time" class="form-control" placeholder="自訂時間 (可選)">
                                    <small class="text-muted">留空則使用當前時間</small>
                                </div>
                                <button type="submit" class="btn btn-success w-100">新增價格記錄</button>
                            </form>
                        </div>
                        <div class="col-md-6">
                            <h6>批量管理:</h6>
                            <a href="/manual_price_interface" class="btn btn-info mb-2 w-100">開啟完整管理介面</a>
                            <a href="/api/export_prices" class="btn btn-secondary mb-2 w-100">匯出價格資料</a>
                            <button class="btn btn-warning mb-2 w-100" onclick="showBatchImport()">批量導入</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card mb-3" id="batchImportCard" style="display: none;">
                <div class="card-header"><h5>批量導入價格</h5></div>
                <div class="card-body">
                    <form method="post" action="/api/batch_import" enctype="multipart/form-data">
                        <div class="mb-3">
                            <label class="form-label">上傳 CSV 檔案:</label>
                            <input type="file" name="csv_file" class="form-control" accept=".csv">
                            <small class="text-muted">格式: 遊戲名稱,價格,時間(可選)</small>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">或直接輸入資料 (每行一筆):</label>
                            <textarea name="manual_data" class="form-control" rows="5" placeholder="Cyberpunk 2077,1790,2024-01-15 14:30&#10;Portal 2,268"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">開始導入</button>
                        <button type="button" class="btn btn-secondary" onclick="hideBatchImport()">取消</button>
                    </form>
                </div>
            </div>
            
            <div class="card mb-3">
                <div class="card-header"><h5>�🔧 系統管理操作</h5></div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>初始化操作:</h6>
                            <button class="btn btn-primary mb-2 w-100" onclick="location.href='/api/db/reinit'">重新初始化資料庫</button>
                            <button class="btn btn-info mb-2 w-100" onclick="location.href='/api/db/sample'">插入範例資料</button>
                        </div>
                        <div class="col-md-6">
                            <h6>維護操作:</h6>
                            <button class="btn btn-warning mb-2 w-100" onclick="location.href='/api/db/backup'">備份資料庫</button>
                            <button class="btn btn-danger mb-2 w-100" onclick="confirmCleanup()">清理舊記錄</button>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="text-center">
                <a href="/debug" class="btn btn-secondary">返回診斷頁面</a>
                <a href="/" class="btn btn-success ms-2">返回首頁</a>
            </div>
        </div>
        
        <script>
        function confirmCleanup() {{
            if (confirm('確定要清理 30 天前的舊記錄嗎？')) {{
                location.href = '/api/db/cleanup';
            }}
        }}
        
        function showBatchImport() {{
            document.getElementById('batchImportCard').style.display = 'block';
        }}
        
        function hideBatchImport() {{
            document.getElementById('batchImportCard').style.display = 'none';
        }}
        </script>
        </body>
        </html>
        """
        
    except Exception as e:
        return f"資料庫管理頁面錯誤: {str(e)}"

# 測試搜尋功能 - 返回固定結果以便測試收藏按鈕
@app.route('/test_search')
def test_search():
    # 模擬一個搜尋結果
    result = {'name': 'Cyberpunk 2077', 'current_price': 'NT$ 1,790'}
    tracked = get_tracked_games()
    user = session.get('user')
    return render_template('index.html', result=result, tracked=tracked, recent=[], user=user)

# 測試連線與 Selenium 狀態
@app.route('/test_selenium')
def test_selenium():
    try:
        from selenium import webdriver
        from selenium.webdriver.chrome.service import Service
        from selenium.webdriver.chrome.options import Options
        from webdriver_manager.chrome import ChromeDriverManager
        import time
        
        # 測試 ChromeDriver 安裝
        try:
            chrome_driver_path = ChromeDriverManager().install()
            chrome_status = f"ChromeDriver 路徑: {chrome_driver_path}"
        except Exception as e:
            chrome_status = f"ChromeDriver 安裝失敗: {str(e)}"
            
        # 測試基本連線
        try:
            chrome_options = Options()
            chrome_options.add_argument('--headless')
            chrome_options.add_argument('--disable-gpu')
            chrome_options.add_argument('--no-sandbox')
            chrome_options.add_argument('--disable-dev-shm-usage')
            
            driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
            driver.get("https://www.google.com")
            time.sleep(2)
            page_title = driver.title
            driver.quit()
            connection_status = f"連線測試成功，Google 頁面標題: {page_title}"
        except Exception as e:
            connection_status = f"連線測試失敗: {str(e)}"
        
        # 測試 Steam 連線
        try:
            chrome_options = Options()
            chrome_options.add_argument('--headless')
            chrome_options.add_argument('--disable-gpu')
            chrome_options.add_argument('--no-sandbox')
            chrome_options.add_argument('--disable-dev-shm-usage')
            
            driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
            driver.get("https://store.steampowered.com/")
            time.sleep(3)
            steam_title = driver.title
            driver.quit()
            steam_status = f"Steam 連線成功，頁面標題: {steam_title}"
        except Exception as e:
            steam_status = f"Steam 連線失敗: {str(e)}"
            
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Selenium 測試結果</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body class="bg-light">
        <div class="container py-5">
            <h1>Selenium 與網路連線測試</h1>
            
            <div class="card mb-3">
                <div class="card-header"><h5>ChromeDriver 狀態</h5></div>
                <div class="card-body">
                    <p>{chrome_status}</p>
                </div>
            </div>
            
            <div class="card mb-3">
                <div class="card-header"><h5>基本網路連線</h5></div>
                <div class="card-body">
                    <p>{connection_status}</p>
                </div>
            </div>
            
            <div class="card mb-3">
                <div class="card-header"><h5>Steam 網站連線</h5></div>
                <div class="card-body">
                    <p>{steam_status}</p>
                </div>
            </div>
            
            <div class="text-center">
                <a href="/" class="btn btn-primary">返回首頁</a>
                <a href="/test_price_query" class="btn btn-warning ms-2">測試價格查詢</a>
            </div>
        </div>
        </body>
        </html>
        """
        
    except Exception as e:
        return f"測試失敗: {str(e)}"

# 測試價格查詢功能
@app.route('/test_price_query')
def test_price_query():
    try:
        # 測試查詢一個簡單的遊戲
        result = get_steam_price("Portal 2")
        
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>價格查詢測試</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body class="bg-light">
        <div class="container py-5">
            <h1>價格查詢測試結果</h1>
            
            <div class="card">
                <div class="card-header"><h5>Portal 2 查詢結果</h5></div>
                <div class="card-body">
                    <p><strong>遊戲名稱:</strong> {result.get('name', 'N/A')}</p>
                    <p><strong>價格:</strong> {result.get('current_price', 'N/A')}</p>
                    {f"<p><strong>錯誤:</strong> {result.get('error', 'N/A')}</p>" if 'error' in result else ""}
                </div>
            </div>
            
            <div class="text-center mt-4">
                <a href="/" class="btn btn-primary">返回首頁</a>
                <a href="/test_selenium" class="btn btn-info ms-2">測試 Selenium</a>
            </div>
        </div>
        </body>
        </html>
        """
        
    except Exception as e:
        return f"測試失敗: {str(e)}"

# 資料庫管理 API
@app.route('/api/db/reinit')
def api_db_reinit():
    try:
        db.init_db()
        init_user_db()
        flash('資料庫重新初始化成功')
    except Exception as e:
        flash(f'資料庫初始化失敗: {str(e)}')
    return redirect(url_for('database_admin'))

@app.route('/api/db/sample')
def api_db_sample():
    try:
        import sqlite3
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        
        # 插入範例遊戲
        sample_games = ["Cyberpunk 2077", "The Witcher 3", "Portal 2", "Half-Life 2"]
        for game in sample_games:
            cursor.execute("INSERT OR IGNORE INTO tracked_games (game_name) VALUES (?)", (game,))
        
        # 插入範例價格
        sample_prices = [
            ("Cyberpunk 2077", 1790.0),
            ("The Witcher 3", 569.0),
            ("Portal 2", 268.0),
            ("Half-Life 2", 188.0)
        ]
        
        for game, price in sample_prices:
            cursor.execute("INSERT INTO price_history (game_name, price) VALUES (?, ?)", (game, price))
        
        conn.commit()
        conn.close()
        flash('範例資料插入成功')
    except Exception as e:
        flash(f'插入範例資料失敗: {str(e)}')
    return redirect(url_for('database_admin'))

@app.route('/api/db/backup')
def api_db_backup():
    try:
        import shutil
        from datetime import datetime
        backup_name = f"prices_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
        shutil.copy2("prices.db", backup_name)
        flash(f'資料庫已備份至: {backup_name}')
    except Exception as e:
        flash(f'備份失敗: {str(e)}')
    return redirect(url_for('database_admin'))

@app.route('/api/db/cleanup')
def api_db_cleanup():
    try:
        deleted = db.cleanup_old_records(30)
        flash(f'已清理 {deleted} 筆舊記錄')
    except Exception as e:
        flash(f'清理失敗: {str(e)}')
    return redirect(url_for('database_admin'))

# 手動插入價格 API
@app.route('/api/manual_price', methods=['POST'])
def api_manual_price():
    try:
        game_name = request.form.get('game_name', '').strip()
        price_str = request.form.get('price', '').strip()
        custom_time = request.form.get('custom_time', '').strip()
        
        if not game_name or not price_str:
            flash('遊戲名稱和價格不能為空')
            return redirect(url_for('database_admin'))
        
        try:
            price = float(price_str)
            if price < 0:
                flash('價格不能為負數')
                return redirect(url_for('database_admin'))
        except ValueError:
            flash('價格格式錯誤')
            return redirect(url_for('database_admin'))
        
        import sqlite3
        from datetime import datetime
        
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        
        if custom_time:
            # 轉換時間格式
            try:
                dt = datetime.fromisoformat(custom_time)
                timestamp = dt.strftime('%Y-%m-%d %H:%M:%S')
                cursor.execute(
                    "INSERT INTO price_history (game_name, price, timestamp) VALUES (?, ?, ?)",
                    (game_name, price, timestamp)
                )
            except ValueError:
                flash('時間格式錯誤')
                return redirect(url_for('database_admin'))
        else:
            cursor.execute(
                "INSERT INTO price_history (game_name, price) VALUES (?, ?)",
                (game_name, price)
            )
        
        conn.commit()
        conn.close()
        
        flash(f'成功新增 {game_name} 的價格記錄: NT$ {price}')
        
    except Exception as e:
        flash(f'新增價格記錄失敗: {str(e)}')
    
    return redirect(url_for('database_admin'))

# 批量導入 API
@app.route('/api/batch_import', methods=['POST'])
def api_batch_import():
    try:
        success_count = 0
        error_count = 0
        lines = []
        
        # 檢查是否有上傳檔案
        if 'csv_file' in request.files and request.files['csv_file'].filename:
            file = request.files['csv_file']
            try:
                content = file.read().decode('utf-8')
                lines = [line.strip() for line in content.split('\n') if line.strip()]
            except Exception as e:
                flash(f'讀取檔案失敗: {str(e)}')
                return redirect(url_for('database_admin'))
        
        # 檢查手動輸入的資料
        manual_data = request.form.get('manual_data', '').strip()
        if manual_data and not lines:
            lines = [line.strip() for line in manual_data.split('\n') if line.strip()]
        
        if not lines:
            flash('沒有資料可導入')
            return redirect(url_for('database_admin'))
        
        import sqlite3
        from datetime import datetime
        
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        
        for i, line in enumerate(lines, 1):
            try:
                parts = [p.strip() for p in line.split(',')]
                if len(parts) < 2:
                    error_count += 1
                    continue
                
                game_name = parts[0]
                price = float(parts[1])
                timestamp = parts[2] if len(parts) > 2 else None
                
                if timestamp:
                    # 驗證時間格式
                    if len(timestamp) == 16:  # YYYY-MM-DD HH:MM
                        timestamp += ":00"
                    datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S")
                    cursor.execute(
                        "INSERT INTO price_history (game_name, price, timestamp) VALUES (?, ?, ?)",
                        (game_name, price, timestamp)
                    )
                else:
                    cursor.execute(
                        "INSERT INTO price_history (game_name, price) VALUES (?, ?)",
                        (game_name, price)
                    )
                
                success_count += 1
                
            except Exception as e:
                error_count += 1
        
        conn.commit()
        conn.close()
        
        flash(f'批量導入完成: 成功 {success_count} 筆, 失敗 {error_count} 筆')
        
    except Exception as e:
        flash(f'批量導入失敗: {str(e)}')
    
    return redirect(url_for('database_admin'))

# 匯出價格資料
@app.route('/api/export_prices')
def api_export_prices():
    try:
        import sqlite3
        from datetime import datetime
        
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT game_name, price, timestamp 
            FROM price_history 
            ORDER BY timestamp DESC
        """)
        
        records = cursor.fetchall()
        conn.close()
        
        # 生成 CSV 內容
        csv_content = "遊戲名稱,價格,時間\n"
        for game, price, timestamp in records:
            csv_content += f'"{game}",{price},"{timestamp}"\n'
        
        # 返回檔案下載
        from flask import Response
        filename = f"steam_prices_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        
        return Response(
            csv_content,
            mimetype='text/csv',
            headers={'Content-Disposition': f'attachment; filename={filename}'}
        )
        
    except Exception as e:
        flash(f'匯出失敗: {str(e)}')
        return redirect(url_for('database_admin'))

# 完整的手動價格管理介面
@app.route('/manual_price_interface')
def manual_price_interface():
    try:
        import sqlite3
        conn = sqlite3.connect("prices.db")
        cursor = conn.cursor()
        
        # 獲取最近的價格記錄
        cursor.execute("""
            SELECT game_name, price, timestamp 
            FROM price_history 
            ORDER BY timestamp DESC 
            LIMIT 20
        """)
        recent_records = cursor.fetchall()
        
        # 獲取遊戲統計
        cursor.execute("""
            SELECT game_name, COUNT(*) as count, MIN(price) as min_price, MAX(price) as max_price
            FROM price_history 
            GROUP BY game_name 
            ORDER BY count DESC
        """)
        game_stats = cursor.fetchall()
        
        conn.close()
        
        return f"""
        <!DOCTYPE html>
        <html lang="zh-Hant">
        <head>
            <meta charset="UTF-8">
            <title>手動價格管理</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body class="bg-light">
        <div class="container py-5">
            <h1>手動價格管理</h1>
            
            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-3">
                        <div class="card-header"><h5>最近記錄</h5></div>
                        <div class="card-body">
                            <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>遊戲</th>
                                            <th>價格</th>
                                            <th>時間</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {''.join([f'<tr><td>{game}</td><td>NT$ {price}</td><td>{timestamp}</td></tr>' for game, price, timestamp in recent_records])}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card mb-3">
                        <div class="card-header"><h5>遊戲統計</h5></div>
                        <div class="card-body">
                            <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>遊戲</th>
                                            <th>記錄數</th>
                                            <th>最低價</th>
                                            <th>最高價</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {''.join([f'<tr><td>{game}</td><td>{count}</td><td>NT$ {min_p}</td><td>NT$ {max_p}</td></tr>' for game, count, min_p, max_p in game_stats])}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="text-center">
                <a href="/database_admin" class="btn btn-primary">返回資料庫管理</a>
                <a href="/" class="btn btn-success ms-2">返回首頁</a>
            </div>
        </div>
        </body>
        </html>
        """
        
    except Exception as e:
        return f"手動價格管理介面錯誤: {str(e)}"

if __name__ == '__main__':
    app.secret_key = 'your_secret_key_here'
    # 在 Docker 中監聽所有介面
    app.run(host='0.0.0.0', port=5000, debug=True)
