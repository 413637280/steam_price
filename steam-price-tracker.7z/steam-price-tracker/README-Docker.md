# Steam Price Tracker - Docker 版本

## 系統需求

- Windows 10/11
- Docker Desktop for Windows
- 至少 2GB 可用記憶體

## 安裝 Docker Desktop

1. 前往 [Docker Desktop 官網](https://www.docker.com/products/docker-desktop) 下載安裝檔
2. 執行安裝檔並依照指示完成安裝
3. 重新啟動電腦
4. 啟動 Docker Desktop

## 快速開始

### 方法一：使用批次檔（推薦）

1. 雙擊 `start-docker.bat` 啟動應用程式
2. 等待建置完成，瀏覽器會自動開啟
3. 使用 `stop-docker.bat` 停止應用程式

### 方法二：使用命令列

1. 開啟 PowerShell 或 命令提示字元
2. 切換到專案目錄：
   ```
   cd "c:\Users\AA\Downloads\steam-price-tracker\steam-price-tracker"
   ```
3. 建立 Docker 映像檔：
   ```
   docker-compose build
   ```
4. 啟動容器：
   ```
   docker-compose up -d
   ```
5. 停止容器：
   ```
   docker-compose down
   ```

## 使用說明

- **主頁面**: http://localhost:5000
- **系統診斷**: http://localhost:5000/debug
- **Selenium 測試**: http://localhost:5000/test_selenium
- **價格查詢測試**: http://localhost:5000/test_price_query

## 常用命令

```bash
# 查看容器狀態
docker-compose ps

# 查看應用程式日誌
docker-compose logs -f

# 重新啟動容器
docker-compose restart

# 重新建置映像檔
docker-compose build --no-cache

# 進入容器內部
docker-compose exec steam-price-tracker bash
```

## 資料持久化

- 資料庫檔案儲存在 `./data` 目錄中
- 即使容器重新啟動，資料也會保留

## 疑難排解

### 問題：容器無法啟動
**解決方案**：
1. 確認 Docker Desktop 正在運行
2. 檢查端口 5000 是否被其他程式佔用
3. 查看日誌：`docker-compose logs`

### 問題：網頁無法訪問
**解決方案**：
1. 確認容器正在運行：`docker-compose ps`
2. 檢查防火牆設定
3. 嘗試使用 http://127.0.0.1:5000

### 問題：Selenium 錯誤
**解決方案**：
1. 訪問 http://localhost:5000/test_selenium 查看詳細錯誤
2. 重新啟動容器：`docker-compose restart`

## 開發模式

如需修改程式碼並即時看到變更：

1. 修改 `docker-compose.yml`，新增 volume 對應：
   ```yaml
   volumes:
     - .:/app
     - ./data:/app/data
   ```
2. 重新啟動容器：`docker-compose restart`

## 效能優化

- 容器會自動處理 Chrome 瀏覽器的記憶體使用
- 預設使用 headless 模式減少資源消耗
- 虛擬顯示器確保 Selenium 正常運作

## 安全注意事項

- 預設密鑰僅供開發使用
- 正式環境請修改 `app.py` 中的 `secret_key`
- 考慮使用 HTTPS 和環境變數來管理敏感資訊
